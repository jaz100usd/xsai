
import { GoogleGenAI, Type } from "@google/genai";
import { LotteryResult, Prediction, DailyRecord } from "../types";

/**
 * Khởi tạo GoogleGenAI client sử dụng API Key từ biến môi trường.
 */
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Phân tích ảnh kết quả xổ số Miền Bắc (XSMB) sử dụng Gemini Flash.
 */
export const extractResultFromImage = async (base64Image: string): Promise<LotteryResult | null> => {
  try {
    const base64Data = base64Image.includes(',') ? base64Image.split(',')[1] : base64Image;

    const prompt = `Phân tích ảnh kết quả xổ số Miền Bắc (XSMB).
    Trích xuất các thông tin sau:
    - Ngày (date): định dạng YYYY-MM-DD
    - Giải Đặc biệt (db): 5 hoặc 6 chữ số
    - G1: 5 chữ số
    - G2: mảng 2 chuỗi
    - G3: mảng 6 chuỗi
    - G4: mảng 4 chuỗi
    - G5: mảng 6 chuỗi
    - G6: mảng 3 chuỗi
    - G7: mảng 4 chuỗi
    - loto: mảng 27 chuỗi là 2 số cuối của toàn bộ các giải từ ĐB đến G7.
    Trả về định dạng JSON chính xác theo schema.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: {
        parts: [
          { inlineData: { mimeType: 'image/png', data: base64Data } },
          { text: prompt }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            date: { type: Type.STRING },
            db: { type: Type.STRING },
            g1: { type: Type.STRING },
            g2: { type: Type.ARRAY, items: { type: Type.STRING } },
            g3: { type: Type.ARRAY, items: { type: Type.STRING } },
            g4: { type: Type.ARRAY, items: { type: Type.STRING } },
            g5: { type: Type.ARRAY, items: { type: Type.STRING } },
            g6: { type: Type.ARRAY, items: { type: Type.STRING } },
            g7: { type: Type.ARRAY, items: { type: Type.STRING } },
            loto: { type: Type.ARRAY, items: { type: Type.STRING } }
          },
          required: ["db", "g1", "g2", "g3", "g4", "g5", "g6", "g7", "loto"]
        }
      }
    });

    if (!response.text) throw new Error("AI không trả về kết quả.");
    return JSON.parse(response.text.trim());
  } catch (error: any) {
    console.error("Lỗi OCR:", error);
    return null;
  }
};

/**
 * Tạo dự đoán dựa trên dữ liệu lịch sử với hệ thống 12 thuật toán chuyên sâu.
 */
export const generatePrediction = async (historicalData: DailyRecord[]): Promise<Prediction | null> => {
  try {
    const rawHistory = historicalData
      .filter(r => r.result !== null)
      .slice(0, 15)
      .map(r => ({
        date: r.date,
        db: r.result?.db,
        loto: r.result?.loto
      }));

    const intelligenceHistory = historicalData
      .filter(r => r.result !== null && r.prediction !== null && r.lessonLearned && r.isCorrect !== null)
      .slice(0, 5)
      .map(r => ({
        date: r.date,
        duDoanCu: { btl: r.prediction?.bachThuLo, stl: r.prediction?.songThuLo },
        ketQuaThucTe: r.isCorrect ? "TRÚNG" : "TRƯỢT",
        baiHocRutRa: r.lessonLearned
      }));

    const prompt = `
    HỆ THỐNG TRÍ TUỆ NHÂN TẠO PHÂN TÍCH XSMB ĐA THUẬT TOÁN (PHIÊN BẢN NÂNG CẤP)
    
    DỮ LIỆU KẾT QUẢ 15 KỲ GẦN NHẤT:
    ${JSON.stringify(rawHistory)}
    
    LỊCH SỬ DỰ ĐOÁN VÀ BÀI HỌC KINH NGHIỆM:
    ${JSON.stringify(intelligenceHistory)}
    
    NHIỆM VỤ:
    Sử dụng tổng hợp 12 phương pháp soi cầu sau để tìm ra con số có xác suất cao nhất:
    1.  BẠC NHỚ CHUYÊN SÂU: Quy luật cặp số hay đi cùng nhau hoặc nổ sau một số cụ thể.
    2.  TAM GIÁC PASCAL: Cộng dồn GĐB + G1 thành dãy số tam giác để tìm số cuối.
    3.  HÌNH QUẢ TRÁM: Cấu trúc đối xứng A-B-A ở các giải 3, 4, 5.
    4.  CẦU KẸP: Tìm số bị "kẹp" giữa hai số giống nhau trong cùng một giải.
    5.  BÓNG ÂM DƯƠNG: Ngũ hành tương sinh tương khắc của các con số.
    6.  SOI CẦU TAM GIÁC: Ghép đầu đuôi của GĐB, G1 và G2.
    7.  TẦN SUẤT MAX GAN: Soi biên độ các số đã lâu chưa về (chạm ngưỡng gan cực đại).
    8.  ĐẦU/ĐUÔI CÂM: Phân tích quy luật khi có đầu/đuôi số không xuất hiện.
    9.  LÔ RƠI: Bắt lại số từ giải đặc biệt hoặc lô gan ngày hôm trước.
    10. CẦU TIẾN LÙI: Quy luật tịnh tiến của các kỳ quay liên tiếp.
    11. CẤU TRÚC GIẢI ĐẶC BIỆT: Phân tích tổng, chạm, đầu/đuôi của GĐB 5 ngày qua.
    12. THUẬT TOÁN BAYES: Xác suất thống kê dựa trên tần suất xuất hiện loto thực tế.

    YÊU CẦU:
    - AI hãy tự chọn 1 hoặc kết hợp 2 thuật toán mạnh nhất hôm nay.
    - Đặt tên thuật toán thật chuyên nghiệp (Viết IN HOA, ví dụ: "BẠC NHỚ ĐẦU YẾU KẾT HỢP CẤU TRÚC GIẢI ĐẶC BIỆT").
    - Ước lượng xác suất chính xác dựa trên dữ liệu thực tế.

    YÊU CẦU ĐẦU RA JSON:
    - bachThuLo: 1 cặp số.
    - songThuLo: 2 cặp số.
    - baCang: 1 số có 3 chữ số.
    - accuracyChance: Số nguyên (Ví dụ: 88).
    - algorithmName: Tên thuật toán (Viết IN HOA).
    - logic: Mô tả chi tiết quá trình phân tích 5 ngày qua và lý do chọn thuật toán này.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            bachThuLo: { type: Type.STRING },
            songThuLo: { type: Type.ARRAY, items: { type: Type.STRING } },
            baCang: { type: Type.STRING },
            accuracyChance: { type: Type.INTEGER },
            algorithmName: { type: Type.STRING },
            logic: { type: Type.STRING }
          },
          required: ["bachThuLo", "songThuLo", "baCang", "accuracyChance", "algorithmName", "logic"]
        }
      }
    });

    if (!response.text) return null;
    return JSON.parse(response.text.trim());
  } catch (error: any) {
    console.error("Lỗi generatePrediction:", error);
    throw error;
  }
};

/**
 * Phân tích độ chính xác của dự đoán so với thực tế.
 */
export const analyzeAccuracy = async (prediction: Prediction, actual: LotteryResult): Promise<{isCorrect: boolean, lesson: string}> => {
  try {
    const prompt = `
    SO SÁNH DỰ ĐOÁN VỚI KẾT QUẢ THỰC TẾ ĐỂ RÚT KINH NGHIỆM
    
    Dự đoán đã đưa ra: ${JSON.stringify(prediction)}
    Kết quả thực tế: ${JSON.stringify(actual)}
    
    Nhiệm vụ:
    1. Xác định xem dự đoán có trúng (BTL hoặc STL) hay không.
    2. Đúc kết 1 bài học ngắn gọn (tối đa 2 câu) để hệ thống sử dụng cho lần dự đoán sau.
    
    Trả về định dạng JSON chính xác.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            isCorrect: { type: Type.BOOLEAN },
            lesson: { type: Type.STRING }
          },
          required: ["isCorrect", "lesson"]
        }
      }
    });
    if (!response.text) return { isCorrect: false, lesson: "Không nhận được phản hồi phân tích." };
    return JSON.parse(response.text.trim());
  } catch (error: any) {
    console.error("Lỗi Phân Tích:", error);
    return { isCorrect: false, lesson: "Lỗi hệ thống khi đúc rút bài học." };
  }
};
