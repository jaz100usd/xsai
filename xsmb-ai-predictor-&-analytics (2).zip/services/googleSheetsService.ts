
import { DailyRecord, AppSettings } from "../types";

/**
 * THÔNG TIN CỐ ĐỊNH CỦA HỆ THỐNG
 */
const FIXED_SHEET_ID = "100GBDQ8RNCyRS2NCO5wRG6kajQ_7wvtt982eXj1dLOM";
// URL này được cập nhật theo logic đồng bộ mới nhất
const FIXED_APPS_SCRIPT_URL = "https://script.google.com/macros/s/AKfycbyv6D0B2I4aP65BrJb6Teav-A7BIWAe5WiSoTMp6aMaAssilpEZXb-viaUWcJb63e09/exec"; 

export const fetchRecordsFromSheets = async (settings: AppSettings): Promise<DailyRecord[]> => {
  const targetUrl = FIXED_APPS_SCRIPT_URL;
  const sheetId = FIXED_SHEET_ID;
  
  if (!targetUrl || targetUrl.includes("YOUR_URL_HERE")) {
    console.warn("Chưa cấu hình URL Apps Script.");
    return [];
  }

  try {
    const fetchUrl = `${targetUrl}?sheetId=${sheetId}&t=${Date.now()}`;
    console.log("Fetching from:", fetchUrl);

    const response = await fetch(fetchUrl, {
      method: 'GET',
      mode: 'cors',
      cache: 'no-store',
      headers: {
        'Accept': 'application/json'
      }
    });

    if (!response.ok) {
      throw new Error(`Máy chủ Google trả về lỗi HTTP ${response.status}`);
    }

    const text = await response.text();
    
    if (text.trim().startsWith("<!DOCTYPE") || text.includes("<html")) {
      throw new Error("Lỗi cấu hình: Ứng dụng nhận được HTML thay vì JSON. Hãy đảm bảo bạn đã chọn 'Anyone' khi Deploy Web App.");
    }

    try {
      const data = JSON.parse(text);
      if (Array.isArray(data)) {
        return data;
      }
      if (data && data.status === 'error') {
        throw new Error(data.message || "Lỗi không xác định từ Apps Script.");
      }
      return [];
    } catch (parseError) {
      throw new Error("Dữ liệu từ Google Sheets không hợp lệ. Hãy kiểm tra lại mã nguồn Apps Script.");
    }
  } catch (error: any) {
    console.error("Lỗi fetchRecordsFromSheets:", error);
    alert(`Không thể tải dữ liệu: ${error.message}`);
    return [];
  }
};

export const syncToGoogleSheets = async (record: DailyRecord, settings: AppSettings) => {
  const targetUrl = FIXED_APPS_SCRIPT_URL;
  if (!targetUrl || targetUrl.includes("YOUR_URL_HERE")) return false;

  const payload = {
    action: 'syncRecord',
    sheetId: FIXED_SHEET_ID,
    record: {
      date: record.date,
      db: record.result?.db || 'N/A',
      prediction_btl: record.prediction?.bachThuLo || 'N/A',
      prediction_stl: record.prediction?.songThuLo.join(', ') || 'N/A',
      prediction_baCang: record.prediction?.baCang || 'N/A',
      isCorrect: record.isCorrect,
      lesson: record.lessonLearned || 'Chưa có phân tích'
    },
    fullObject: record 
  };

  try {
    await fetch(targetUrl, {
      method: 'POST',
      mode: 'no-cors', 
      headers: {
        'Content-Type': 'text/plain', 
      },
      body: JSON.stringify(payload),
    });
    return true;
  } catch (error) {
    console.error("Lỗi syncToGoogleSheets:", error);
    return false;
  }
};
