
export interface LotteryResult {
  date: string;
  db: string;
  g1: string;
  g2: string[];
  g3: string[];
  g4: string[];
  g5: string[];
  g6: string[];
  g7: string[];
  loto: string[];
}

export interface Prediction {
  date: string;
  songThuLo: string[]; // 2 pairs
  bachThuLo: string;
  baCang: string;      // 3-digit number
  logic: string;
  accuracyChance: number; // Phần trăm xác suất dự đoán (0-100)
  algorithmName: string;  // Tên thuật toán AI áp dụng
}

export interface DailyRecord {
  id: string;
  date: string;
  result: LotteryResult | null;
  prediction: Prediction | null;
  lessonLearned: string;
  isCorrect: boolean | null;
}

export interface AppSettings {
  // API Key is managed via process.env.API_KEY as per guidelines
}

export enum AppTab {
  DASHBOARD = 'dashboard',
  HISTORY = 'history',
  ANALYTICS = 'analytics',
  SETTINGS = 'settings'
}
