
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { 
  LayoutDashboard, 
  History, 
  Settings as SettingsIcon, 
  BrainCircuit, 
  Database,
  Upload,
  TrendingUp,
  XCircle,
  CheckCircle2,
  Lock,
  RefreshCw,
  CloudDownload,
  AlertCircle,
  Bell,
  Quote,
  ChevronRight,
  Target,
  Info,
  Lightbulb,
  LogOut,
  ShieldCheck,
  Plus,
  Cpu
} from 'lucide-react';
import { AppTab, DailyRecord, Prediction } from './types';
import { extractResultFromImage, generatePrediction, analyzeAccuracy } from './services/geminiService';
import { syncToGoogleSheets, fetchRecordsFromSheets } from './services/googleSheetsService';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

// UI Components
const Card: React.FC<{ children: React.ReactNode; className?: string; onClick?: () => void }> = ({ children, className = "", onClick }) => (
  <div 
    onClick={onClick}
    className={`bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden ${onClick ? 'cursor-pointer hover:border-indigo-300 hover:shadow-md transition-all active:scale-[0.98]' : ''} ${className}`}
  >
    {children}
  </div>
);

const Button: React.FC<{ 
  onClick?: () => void; 
  variant?: 'primary' | 'secondary' | 'danger' | 'ghost' | 'success'; 
  children: React.ReactNode; 
  className?: string;
  disabled?: boolean;
}> = ({ onClick, variant = 'primary', children, className = "", disabled }) => {
  const variants = {
    primary: 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-indigo-100',
    secondary: 'bg-slate-100 text-slate-900 hover:bg-slate-200',
    danger: 'bg-red-50 text-red-600 hover:bg-red-100',
    ghost: 'bg-transparent text-slate-600 hover:bg-slate-50',
    success: 'bg-emerald-600 text-white hover:bg-emerald-700 shadow-emerald-100'
  };
  return (
    <button 
      onClick={onClick} 
      disabled={disabled}
      className={`px-4 py-2 rounded-xl font-medium transition-all flex items-center justify-center gap-2 active:scale-95 disabled:opacity-50 disabled:active:scale-100 ${variants[variant]} ${className}`}
    >
      {children}
    </button>
  );
};

const TabItem: React.FC<{ active: boolean; icon: any; label: string; onClick: () => void }> = ({ active, icon: Icon, label, onClick }) => (
  <button 
    onClick={onClick}
    className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${active ? 'bg-indigo-50 text-indigo-700 font-semibold' : 'text-slate-500 hover:bg-slate-50'}`}
  >
    <Icon size={20} strokeWidth={active ? 2.5 : 2} />
    <span className="text-sm">{label}</span>
  </button>
);

const App: React.FC = () => {
  // Authentication State
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [loginPassword, setLoginPassword] = useState("");
  const DEFAULT_PASSWORD = "hung1109";

  const [activeTab, setActiveTab] = useState<AppTab>(AppTab.DASHBOARD);
  const [records, setRecords] = useState<DailyRecord[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedHistoryRecord, setSelectedHistoryRecord] = useState<DailyRecord | null>(null);
  const [notification, setNotification] = useState<{message: string, type: 'info' | 'success' | 'error'} | null>(null);
  
  // Security for Settings
  const [isSettingsUnlocked, setIsSettingsUnlocked] = useState(false);
  const [passwordInput, setPasswordInput] = useState("");

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Load Data
  useEffect(() => {
    if (sessionStorage.getItem('is_logged_in') === 'true') setIsAuthenticated(true);
    
    const savedRecords = localStorage.getItem('xsmb_records');
    if (savedRecords) {
      try {
        const parsed = JSON.parse(savedRecords);
        if (Array.isArray(parsed)) setRecords(parsed);
      } catch (e) { console.error("Error loading records:", e); }
    }
  }, []);

  // Sync to Storage
  useEffect(() => {
    localStorage.setItem('xsmb_records', JSON.stringify(records));
  }, [records]);

  // Global Paste
  useEffect(() => {
    const handleGlobalPaste = (e: ClipboardEvent) => {
      if (!isAuthenticated) return;
      if (['INPUT', 'TEXTAREA'].includes(document.activeElement?.tagName || '')) return;
      const items = e.clipboardData?.items;
      if (!items) return;
      for (let i = 0; i < items.length; i++) {
        if (items[i].type.indexOf("image") !== -1) {
          const blob = items[i].getAsFile();
          if (blob) {
            const reader = new FileReader();
            reader.onloadend = () => {
              setPreviewImage(reader.result as string);
              setShowAddModal(true);
            };
            reader.readAsDataURL(blob);
            break; 
          }
        }
      }
    };
    window.addEventListener('paste', handleGlobalPaste);
    return () => window.removeEventListener('paste', handleGlobalPaste);
  }, [isAuthenticated]);

  const showToast = (message: string, type: 'info' | 'success' | 'error' = 'info') => {
    setNotification({ message, type });
    setTimeout(() => setNotification(null), 5000);
  };

  const handleLogin = (e?: React.FormEvent) => {
    e?.preventDefault();
    if (loginPassword === DEFAULT_PASSWORD) {
      setIsAuthenticated(true);
      sessionStorage.setItem('is_logged_in', 'true');
      showToast("Đăng nhập thành công!", "success");
    } else {
      showToast("Mật khẩu không chính xác!", "error");
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    sessionStorage.removeItem('is_logged_in');
    setLoginPassword("");
    showToast("Đã đăng xuất", "info");
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setPreviewImage(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleSyncFromCloud = async () => {
    setIsSyncing(true);
    try {
      const cloudRecords = await fetchRecordsFromSheets({});
      if (cloudRecords && cloudRecords.length > 0) {
        const mergedMap = new Map();
        records.forEach(r => mergedMap.set(r.date, r));
        cloudRecords.forEach(r => mergedMap.set(r.date, r));
        const mergedArray = Array.from(mergedMap.values());
        mergedArray.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
        setRecords(mergedArray);
        showToast(`Đồng bộ thành công!`, 'success');
      }
    } catch (err) {
      showToast("Lỗi đồng bộ.", "error");
    } finally {
      setIsSyncing(false);
    }
  };

  const processImage = async () => {
    if (!previewImage) return;
    setIsProcessing(true);
    try {
      const result = await extractResultFromImage(previewImage);
      if (result) {
        const existingRecordIdx = records.findIndex(r => r.date === result.date);
        let updatedRecord: DailyRecord;
        if (existingRecordIdx !== -1) {
          const existing = records[existingRecordIdx];
          const analysis = existing.prediction 
            ? await analyzeAccuracy(existing.prediction, result) 
            : { isCorrect: false, lesson: "Không có dự đoán." };
          updatedRecord = { ...existing, result, isCorrect: analysis.isCorrect, lessonLearned: analysis.lesson };
          const newRecords = [...records];
          newRecords[existingRecordIdx] = updatedRecord;
          setRecords(newRecords);
        } else {
          updatedRecord = {
            id: crypto.randomUUID(), date: result.date || new Date().toISOString().split('T')[0],
            result, prediction: null, lessonLearned: "Cập nhật qua quét ảnh.", isCorrect: null
          };
          setRecords([updatedRecord, ...records]);
        }
        await syncToGoogleSheets(updatedRecord, {});
        setPreviewImage(null);
        setShowAddModal(false);
        showToast("Cập nhật thành công!", "success");
      }
    } catch (err) {
      showToast("Lỗi xử lý ảnh.", "error");
    } finally {
      setIsProcessing(false);
    }
  };

  const handlePredict = async () => {
    const now = new Date();
    const currentHour = now.getHours();
    let targetDate = new Date();
    if (currentHour >= 16) targetDate.setDate(targetDate.getDate() + 1);
    const targetDateStr = targetDate.toISOString().split('T')[0];
    
    if (records.some(r => r.date === targetDateStr && r.prediction !== null)) {
      showToast("Đã có dự đoán cho kỳ này.", "info");
      return;
    }
    if (records.filter(r => r.result !== null).length === 0) {
      showToast("Cần ít nhất 1 bản ghi thực tế.", "error");
      return;
    }
    setIsProcessing(true);
    try {
      const prediction = await generatePrediction(records);
      if (prediction) {
        const newRecord: DailyRecord = {
          id: crypto.randomUUID(), date: targetDateStr, result: null, prediction,
          lessonLearned: "Đang chờ kết quả...", isCorrect: null
        };
        setRecords([newRecord, ...records]);
        await syncToGoogleSheets(newRecord, {});
        showToast("Đã tạo dự đoán!", "success");
      }
    } catch (err) {
      showToast("Lỗi AI.", "error");
    } finally {
      setIsProcessing(false);
    }
  };

  const accuracyData = records.filter(r => r.isCorrect !== null)
    .map(r => ({ date: r.date, score: r.isCorrect ? 100 : 0 })).reverse();

  // LOGIN SCREEN
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-slate-100 flex items-center justify-center p-6 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-indigo-50 via-slate-100 to-indigo-100">
        <Card className="w-full max-w-md p-8 shadow-2xl border-indigo-200/50 backdrop-blur-md bg-white/90">
          <div className="flex flex-col items-center mb-8">
            <div className="bg-indigo-600 p-4 rounded-3xl shadow-lg shadow-indigo-200 mb-4">
              <ShieldCheck size={48} className="text-white" />
            </div>
            <h1 className="text-2xl font-black text-slate-900 tracking-tight">AI XSMB Predictor</h1>
            <p className="text-slate-500 text-sm mt-1">Đăng nhập bằng mật khẩu hệ thống</p>
          </div>
          <form onSubmit={handleLogin} className="space-y-6">
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Mật khẩu</label>
              <div className="relative">
                <input type="password" value={loginPassword} onChange={(e) => setLoginPassword(e.target.value)}
                  className="w-full pl-12 pr-4 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl outline-none focus:border-indigo-500 focus:bg-white transition-all text-lg font-bold tracking-widest"
                  placeholder="••••••••" autoFocus />
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={20} />
              </div>
            </div>
            <Button variant="primary" className="w-full py-4 text-lg">Đăng nhập</Button>
          </form>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col md:flex-row relative">
      {notification && (
        <div className="fixed top-6 left-1/2 -translate-x-1/2 z-[100] animate-in slide-in-from-top duration-300">
          <div className={`px-6 py-4 rounded-2xl shadow-2xl border flex items-center gap-3 min-w-[320px] ${
            notification.type === 'success' ? 'bg-emerald-50 border-emerald-200 text-emerald-800' :
            notification.type === 'error' ? 'bg-red-50 border-red-200 text-red-800' : 'bg-amber-50 border-amber-200 text-amber-800'
          }`}>
            {notification.type === 'success' ? <CheckCircle2 size={18} /> : notification.type === 'error' ? <AlertCircle size={18} /> : <Bell size={18} />}
            <p className="font-bold text-sm">{notification.message}</p>
          </div>
        </div>
      )}

      {/* Sidebar */}
      <aside className="w-full md:w-64 bg-white border-b md:border-r border-slate-200 p-4 flex flex-col gap-2 z-20">
        <div className="flex items-center gap-3 px-4 py-6 mb-4">
          <BrainCircuit className="text-indigo-600" size={32} />
          <span className="font-bold text-xl tracking-tight text-slate-900">AI XSMB</span>
        </div>
        <TabItem active={activeTab === AppTab.DASHBOARD} icon={LayoutDashboard} label="Bảng điều khiển" onClick={() => setActiveTab(AppTab.DASHBOARD)} />
        <TabItem active={activeTab === AppTab.HISTORY} icon={History} label="Lịch sử" onClick={() => setActiveTab(AppTab.HISTORY)} />
        <TabItem active={activeTab === AppTab.SETTINGS} icon={SettingsIcon} label="Cài đặt" onClick={() => setActiveTab(AppTab.SETTINGS)} />
        
        <div className="mt-8 border-t border-slate-100 pt-4 px-2">
          <button onClick={handleLogout} className="flex items-center gap-3 w-full px-4 py-3 rounded-xl transition-all text-rose-500 hover:bg-rose-50 font-medium">
            <LogOut size={20} /> <span className="text-sm">Thoát hệ thống</span>
          </button>
        </div>

        <div className="mt-auto p-4 bg-indigo-50 rounded-xl border border-indigo-100">
          <Button onClick={handleSyncFromCloud} variant="ghost" className="w-full text-xs py-1 text-indigo-600" disabled={isSyncing}>
            <CloudDownload size={14} /> {isSyncing ? "Đang tải..." : "Đồng bộ đám mây"}
          </Button>
        </div>
      </aside>

      <main className="flex-1 p-4 md:p-8 overflow-auto">
        <header className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
          <div>
            <h1 className="text-2xl font-bold text-slate-900">{activeTab === AppTab.DASHBOARD ? 'Tổng quan' : activeTab === AppTab.HISTORY ? 'Lịch sử' : 'Cài đặt'}</h1>
            <p className="text-slate-500 text-sm">XSMB AI Predictor & Analytics</p>
          </div>
          <div className="flex gap-2">
            <Button onClick={() => setShowAddModal(true)} variant="secondary"><Upload size={18} /> Quét ảnh</Button>
            <Button onClick={handlePredict} variant="primary" disabled={isProcessing}><BrainCircuit size={18} /> {isProcessing ? "Đang xử lý..." : "Dự đoán"}</Button>
          </div>
        </header>

        {activeTab === AppTab.DASHBOARD && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
               <Card className="p-6 bg-indigo-600 text-white shadow-lg shadow-indigo-100">
                 <p className="text-indigo-100 text-xs font-bold uppercase mb-1">Dữ liệu hiện tại</p>
                 <p className="text-4xl font-black">{records.length} kỳ</p>
               </Card>
               <Card className="p-6 border-emerald-100 bg-emerald-50">
                 <p className="text-emerald-600 text-xs font-bold uppercase mb-1">Tỉ lệ chính xác (AI)</p>
                 <p className="text-4xl font-black text-emerald-700">
                   {records.filter(r => r.isCorrect !== null).length > 0 
                     ? (records.filter(r => r.isCorrect === true).length / (records.filter(r => r.isCorrect !== null).length) * 100).toFixed(1) : '0'}%
                 </p>
               </Card>
               <Card className="p-6">
                 <p className="text-slate-400 text-xs font-bold uppercase mb-1">Kỳ quay gần nhất</p>
                 <p className="text-2xl font-bold text-slate-700">{records.find(r => r.result)?.date || '---'}</p>
               </Card>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="p-6 min-h-[300px]">
                <h3 className="font-bold mb-4 flex items-center gap-2"><TrendingUp size={18} className="text-indigo-600"/> Hiệu suất dự đoán</h3>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={accuracyData}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                      <XAxis dataKey="date" hide />
                      <YAxis hide domain={[0, 100]} />
                      <Area type="monotone" dataKey="score" stroke="#4f46e5" fill="#4f46e520" strokeWidth={3} />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </Card>

              <Card className="p-6">
                <div className="flex justify-between items-center mb-6">
                  <h3 className="font-bold flex items-center gap-2 text-indigo-900"><BrainCircuit size={20} className="text-indigo-600"/> Dự đoán mới nhất</h3>
                  {records[0]?.prediction && (
                    <div className="flex gap-2">
                       <span className="flex items-center gap-1 bg-emerald-100 text-emerald-700 text-[10px] font-black px-2 py-1 rounded-md uppercase">
                         <Target size={12}/> {records[0].prediction.accuracyChance}%
                       </span>
                       <span className="flex items-center gap-1 bg-indigo-100 text-indigo-700 text-[10px] font-black px-2 py-1 rounded-md uppercase">
                         <Cpu size={12}/> {records[0].prediction.algorithmName}
                       </span>
                    </div>
                  )}
                </div>
                {records.length > 0 && records[0].prediction ? (
                  <div className="space-y-6">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="p-4 bg-indigo-50 rounded-2xl border border-indigo-100 text-center">
                        <p className="text-[10px] text-indigo-400 font-bold uppercase mb-1">Bạch Thủ Lô</p>
                        <p className="text-4xl font-black text-indigo-700">{records[0].prediction.bachThuLo}</p>
                      </div>
                      <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 text-center">
                        <p className="text-[10px] text-slate-400 font-bold uppercase mb-1">Song Thủ Lô</p>
                        <p className="text-xl font-bold text-slate-700 leading-8">{records[0].prediction.songThuLo.join(' - ')}</p>
                      </div>
                    </div>
                    <div className="p-4 bg-amber-50 rounded-2xl border border-amber-200 text-center">
                      <p className="text-[10px] text-amber-500 font-bold uppercase mb-1">Ba Càng</p>
                      <p className="text-2xl font-black text-amber-700 tracking-[0.2em]">{records[0].prediction.baCang}</p>
                    </div>
                    <div className="pt-4 border-t border-slate-100">
                      <p className="text-[10px] text-slate-400 font-bold uppercase mb-2 flex items-center gap-2">
                        <Info size={14} className="text-indigo-500"/> Cơ sở soi cầu (Thống kê 5 ngày):
                      </p>
                      <p className="text-xs text-slate-600 leading-relaxed italic bg-slate-50 p-4 rounded-xl border border-slate-100">
                        {records[0].prediction.logic}
                      </p>
                    </div>
                  </div>
                ) : <p className="text-center text-slate-300 py-20 italic">Chưa có dự đoán cho hôm nay</p>}
              </Card>
            </div>
          </div>
        )}

        {activeTab === AppTab.HISTORY && (
          <div className="space-y-3">
            {records.map(record => (
              <Card key={record.id} className="p-4 flex items-center gap-4 group" onClick={() => setSelectedHistoryRecord(record)}>
                <div className="w-12 text-center">
                  <p className="text-[10px] font-bold text-slate-400 uppercase">{record.date.split('-')[2]}</p>
                  <p className="text-[10px] text-slate-400 leading-none">T{record.date.split('-')[1]}</p>
                </div>
                <div className={`w-2 h-10 rounded-full ${record.isCorrect === true ? 'bg-emerald-500' : record.isCorrect === false ? 'bg-rose-500' : 'bg-slate-300'}`} />
                <div className="flex-1">
                  <span className="font-bold text-slate-800">{record.date}</span>
                  <span className={`ml-3 text-[10px] font-bold px-2 py-0.5 rounded-full uppercase ${record.isCorrect === true ? 'bg-emerald-100 text-emerald-700' : record.isCorrect === false ? 'bg-rose-100 text-rose-700' : 'bg-slate-100 text-slate-500'}`}>
                    {record.isCorrect === true ? 'Trúng' : record.isCorrect === false ? 'Trượt' : 'Chờ KQ'}
                  </span>
                </div>
                <div className="text-right flex items-center gap-4">
                  {record.prediction && (
                    <div className="hidden sm:block">
                      <p className="text-[10px] text-slate-400 font-bold uppercase leading-none">Tin cậy</p>
                      <p className="text-xs font-black text-emerald-600">{record.prediction.accuracyChance}%</p>
                    </div>
                  )}
                  <div>
                    <p className="text-[10px] text-slate-400 uppercase">Bạch Thủ</p>
                    <p className="text-sm font-black text-indigo-600">{record.prediction?.bachThuLo || '--'}</p>
                  </div>
                  <ChevronRight size={20} className="text-slate-300 group-hover:text-indigo-500" />
                </div>
              </Card>
            ))}
          </div>
        )}

        {activeTab === AppTab.SETTINGS && (
          <div className="max-w-3xl space-y-6">
            <Card className="p-8">
              {!isSettingsUnlocked ? (
                <div className="space-y-6 max-w-md mx-auto py-10">
                  <div className="text-center">
                    <Lock size={48} className="mx-auto text-amber-500 mb-4" />
                    <h3 className="font-bold text-slate-800 text-xl">Cài đặt hệ thống bị khóa</h3>
                    <p className="text-slate-400 text-sm mt-1">Vui lòng nhập mật khẩu quản trị</p>
                  </div>
                  <input type="password" value={passwordInput} onChange={(e) => setPasswordInput(e.target.value)}
                    className="w-full px-5 py-3 border-2 border-slate-100 rounded-2xl outline-none focus:border-indigo-500" placeholder="••••••••" />
                  <Button onClick={() => { if(passwordInput === DEFAULT_PASSWORD) setIsSettingsUnlocked(true); else showToast("Sai mật khẩu!", "error"); }} className="w-full py-3">Mở khóa cài đặt</Button>
                </div>
              ) : (
                <div className="space-y-10 animate-in fade-in slide-in-from-bottom-2 duration-500">
                  <div className="flex justify-between items-center border-b pb-6 border-slate-100">
                    <div className="flex items-center gap-3">
                      <div className="bg-emerald-100 p-2 rounded-xl text-emerald-600">
                        <ShieldCheck size={24} />
                      </div>
                      <h3 className="text-xl font-black text-slate-900">Quản trị hệ thống</h3>
                    </div>
                    <Button variant="ghost" onClick={() => setIsSettingsUnlocked(false)} className="text-slate-400">
                      <Lock size={16} /> Khóa lại
                    </Button>
                  </div>

                  <div className="pt-10 border-t border-slate-100 grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="p-6 bg-rose-50 rounded-3xl border border-rose-100">
                       <h5 className="font-bold text-rose-800 flex items-center gap-2 mb-2"><AlertCircle size={18}/> Vùng nguy hiểm</h5>
                       <p className="text-xs text-rose-600 mb-4">Lưu ý: Thao tác này sẽ xóa sạch dữ liệu lịch sử và các cài đặt của bạn trên trình duyệt này.</p>
                       <Button variant="danger" className="w-full py-3" onClick={() => { if(confirm("Xác nhận xóa sạch LocalStorage?")) { localStorage.clear(); window.location.reload(); } }}>Xóa toàn bộ dữ liệu</Button>
                    </div>
                    <div className="p-6 bg-slate-100 rounded-3xl border border-slate-200 flex flex-col items-center justify-center text-center">
                       <Database size={32} className="text-slate-400 mb-2" />
                       <p className="text-sm font-bold text-slate-700">Phiên bản 2.5</p>
                       <p className="text-[10px] text-slate-400 mt-1 uppercase tracking-widest font-bold">Powered by Gemini AI</p>
                    </div>
                  </div>
                </div>
              )}
            </Card>
          </div>
        )}

        {/* DETAILS MODAL */}
        {selectedHistoryRecord && (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md flex items-center justify-center p-4 z-[60] animate-in fade-in duration-300">
             <Card className="w-full max-w-2xl max-h-[90vh] overflow-y-auto p-0 shadow-2xl animate-in zoom-in duration-300">
                <div className="sticky top-0 bg-white border-b p-6 flex justify-between items-center z-10">
                   <div>
                      <h3 className="text-xl font-black">Kết quả {selectedHistoryRecord.date}</h3>
                      {selectedHistoryRecord.prediction && (
                        <div className="flex gap-2 mt-1">
                          <span className="bg-emerald-100 text-emerald-700 text-[9px] font-black px-2 py-0.5 rounded uppercase">Độ tin cậy: {selectedHistoryRecord.prediction.accuracyChance}%</span>
                          <span className="bg-indigo-100 text-indigo-700 text-[9px] font-black px-2 py-0.5 rounded uppercase">{selectedHistoryRecord.prediction.algorithmName}</span>
                        </div>
                      )}
                   </div>
                   <button onClick={() => setSelectedHistoryRecord(null)} className="text-slate-400 hover:text-slate-600 transition-colors"><XCircle size={24} /></button>
                </div>
                <div className="p-8 space-y-8">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <h4 className="text-sm font-bold text-indigo-600 uppercase flex items-center gap-2"><BrainCircuit size={16}/> Dự đoán ban đầu</h4>
                      <div className="p-5 bg-indigo-50 rounded-2xl border border-indigo-100">
                        <p className="text-[10px] text-indigo-400 font-bold uppercase mb-1">Bạch Thủ Lô</p>
                        <p className="text-2xl font-black text-indigo-700">{selectedHistoryRecord.prediction?.bachThuLo || 'N/A'}</p>
                      </div>
                    </div>
                    <div className="space-y-4">
                      <h4 className="text-sm font-bold text-rose-600 uppercase flex items-center gap-2"><Target size={16}/> Thực tế kỳ quay</h4>
                      <div className="p-5 bg-rose-50 rounded-2xl border border-rose-100">
                        <p className="text-[10px] text-rose-400 font-bold uppercase mb-1">Giải Đặc Biệt</p>
                        <p className="text-2xl font-black text-rose-700 tracking-widest">{selectedHistoryRecord.result?.db || 'CHƯA CÓ'}</p>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <h4 className="text-sm font-bold text-slate-600 uppercase flex items-center gap-2"><Info size={16}/> Cơ sở phân tích</h4>
                    <div className="p-6 bg-slate-50 rounded-2xl border border-slate-200 relative">
                       <Quote size={20} className="absolute -top-2 -left-2 text-slate-200 fill-slate-50" />
                       <p className="text-slate-700 italic text-sm leading-relaxed">{selectedHistoryRecord.prediction?.logic || 'Không có dữ liệu phân tích.'}</p>
                    </div>
                  </div>
                  {selectedHistoryRecord.lessonLearned && (
                    <div className="space-y-3">
                      <h4 className="text-sm font-bold text-emerald-600 uppercase flex items-center gap-2"><Lightbulb size={16}/> Bài học kinh nghiệm</h4>
                      <div className="p-6 bg-emerald-50 rounded-2xl border border-emerald-100">
                        <p className="text-emerald-800 text-sm leading-relaxed font-medium">{selectedHistoryRecord.lessonLearned}</p>
                      </div>
                    </div>
                  )}
                </div>
                <div className="p-6 border-t flex justify-end"><Button variant="secondary" onClick={() => setSelectedHistoryRecord(null)}>Đóng chi tiết</Button></div>
             </Card>
          </div>
        )}

        {/* UPLOAD MODAL */}
        {showAddModal && (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-in fade-in duration-200">
            <Card className="w-full max-w-lg p-6 animate-in zoom-in duration-300">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-bold text-slate-900">Quét ảnh kết quả mới</h3>
                <XCircle className="text-slate-400 cursor-pointer hover:text-rose-500 transition-colors" onClick={() => setShowAddModal(false)} />
              </div>
              <div className="border-4 border-dashed border-slate-100 rounded-3xl p-10 text-center cursor-pointer hover:border-indigo-200 transition-all bg-slate-50/50" onClick={() => fileInputRef.current?.click()}>
                <Upload size={48} className="mx-auto text-slate-300 mb-4" />
                <p className="text-slate-600 font-medium text-lg">Chọn tệp ảnh hoặc <span className="text-indigo-600 font-black">Dán (Ctrl+V)</span></p>
                <p className="text-[10px] text-slate-400 mt-2 uppercase font-bold tracking-widest">Hỗ trợ định dạng PNG, JPG, WEBP</p>
                <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleFileUpload} />
              </div>
              {previewImage && (
                <div className="mt-6 rounded-2xl overflow-hidden border-2 border-slate-100 shadow-inner">
                  <img src={previewImage} className="w-full h-48 object-contain bg-slate-200" alt="Preview" />
                </div>
              )}
              <div className="flex gap-4 mt-8">
                <Button onClick={() => { setShowAddModal(false); setPreviewImage(null); }} variant="ghost" className="flex-1 py-3">Hủy bỏ</Button>
                <Button onClick={processImage} variant="primary" className="flex-1 py-3" disabled={isProcessing || !previewImage}>
                  {isProcessing ? "Đang xử lý AI..." : "Phân tích ngay"}
                </Button>
              </div>
            </Card>
          </div>
        )}
      </main>
    </div>
  );
};

export default App;
